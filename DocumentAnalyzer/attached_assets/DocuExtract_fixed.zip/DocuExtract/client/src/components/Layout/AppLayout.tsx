import React, { useState } from 'react';
import Sidebar from './Sidebar';
import { useMediaQuery } from '@/hooks/use-mobile';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const isMobile = useMediaQuery('(max-width: 768px)');
  const [showSidebar, setShowSidebar] = useState(false);

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      {/* Mobile header */}
      {isMobile && (
        <div className="bg-white border-b border-gray-200 fixed top-0 inset-x-0 z-10">
          <div className="flex items-center justify-between h-16 px-4">
            <div className="flex items-center">
              <div className="bg-primary text-white p-1.5 rounded-lg">
                <i className="ri-file-search-line text-xl"></i>
              </div>
              <h1 className="ml-3 text-lg font-bold text-gray-900">DocuScan AI</h1>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSidebar}
              className="text-gray-500"
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      )}

      {/* Sidebar - visible on desktop, or when toggled on mobile */}
      <div className={`${isMobile ? (showSidebar ? 'fixed inset-0 z-20' : 'hidden') : 'flex w-64'}`}>
        {/* Backdrop for mobile */}
        {isMobile && showSidebar && (
          <div 
            className="fixed inset-0 bg-gray-500 bg-opacity-75"
            onClick={toggleSidebar}
          />
        )}
        <Sidebar onClose={isMobile ? toggleSidebar : undefined} />
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-y-auto">
        <main className="flex-1 pb-8 pt-0 md:pt-0">
          {isMobile && (
            <div className="h-16"></div> // Spacer for mobile header
          )}
          {children}
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
