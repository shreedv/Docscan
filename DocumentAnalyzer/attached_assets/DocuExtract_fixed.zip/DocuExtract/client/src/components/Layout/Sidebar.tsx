import React from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { 
  HomeIcon, 
  UploadIcon, 
  FileTextIcon, 
  FileIcon, 
  SettingsIcon, 
  XIcon 
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface SidebarProps {
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onClose }) => {
  const [location] = useLocation();

  // Get stats for the progress bar
  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Calculate progress percentage with default fallback
  const documentsProcessed = stats?.processedCount || 0;
  const documentsTotal = 20; // Free plan limit
  const progressPercentage = Math.min(100, Math.round((documentsProcessed / documentsTotal) * 100));

  const navItems = [
    { path: '/', label: 'Dashboard', icon: <HomeIcon className="mr-3 h-5 w-5" /> },
    { path: '/upload', label: 'Upload Documents', icon: <UploadIcon className="mr-3 h-5 w-5" /> },
    { path: '/documents', label: 'My Documents', icon: <FileTextIcon className="mr-3 h-5 w-5" /> },
    { path: '/templates', label: 'Templates', icon: <FileIcon className="mr-3 h-5 w-5" /> },
    { path: '/settings', label: 'Settings', icon: <SettingsIcon className="mr-3 h-5 w-5" /> },
  ];

  return (
    <div className="flex flex-col flex-grow pt-5 overflow-y-auto bg-white border-r border-gray-200 z-30">
      <div className="flex items-center justify-between flex-shrink-0 px-6 mb-6">
        <div className="flex items-center">
          <div className="bg-primary text-white p-2 rounded-lg">
            <FileTextIcon className="h-5 w-5" />
          </div>
          <h1 className="ml-3 text-xl font-bold text-gray-900">DocuScan AI</h1>
        </div>
        {onClose && (
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose}
            className="md:hidden text-gray-500"
          >
            <XIcon className="h-5 w-5" />
          </Button>
        )}
      </div>

      <div className="flex flex-col flex-grow px-4 mt-5">
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path} className={`flex items-center px-4 py-3 text-sm font-medium rounded-md group ${
                  location === item.path
                    ? 'text-primary bg-primary/10'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}>
                {React.cloneElement(item.icon, { 
                  className: `${item.icon.props.className} ${location === item.path ? 'text-primary' : 'text-gray-500'}` 
                })}
                {item.label}
            </Link>
          ))}
        </nav>
      </div>

      <div className="px-4 py-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-sm font-medium text-gray-700">Free Plan</p>
          <p className="text-xs text-gray-500 mt-1">{documentsProcessed}/{documentsTotal} documents processed</p>
          <div className="w-full h-2 bg-gray-200 rounded-full mt-2">
            <div 
              className="h-2 bg-primary rounded-full" 
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
          <Button 
            className="mt-3 w-full"
            variant="default"
            size="sm"
          >
            Upgrade Plan
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;