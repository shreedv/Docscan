import React, { useState } from 'react';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormDescription 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { DocumentItem, ExtractedDocumentData } from '@/lib/types';
import { Trash, Plus, X } from 'lucide-react';
import { useForm } from 'react-hook-form';

interface ExtractedDataFormProps {
  data: ExtractedDocumentData;
  onUpdate: (data: ExtractedDocumentData) => void;
  isSubmitting?: boolean;
}

const ExtractedDataForm: React.FC<ExtractedDataFormProps> = ({ 
  data, 
  onUpdate,
  isSubmitting = false
}) => {
  const [tags, setTags] = useState<string[]>(data.tags || []);
  const [newTag, setNewTag] = useState<string>('');
  
  // Use react-hook-form
  const form = useForm<ExtractedDocumentData>({
    defaultValues: {
      vendor: data.vendor || '',
      date: data.date || '',
      invoiceNumber: data.invoiceNumber || '',
      paymentMethod: data.paymentMethod || '',
      description: data.description || '',
      subtotal: data.subtotal || '',
      tax: data.tax || '',
      total: data.total || '',
      items: data.items || [{ description: '', quantity: 1, price: '' }],
    },
  });
  
  // Watch form values
  const items = form.watch('items');
  
  // Add new item
  const addItem = () => {
    const newItems = [
      ...items,
      { description: '', quantity: 1, price: '' }
    ];
    form.setValue('items', newItems);
  };
  
  // Remove item
  const removeItem = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    form.setValue('items', newItems);
  };
  
  // Update item
  const updateItem = (index: number, field: keyof DocumentItem, value: string | number) => {
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      [field]: value
    };
    form.setValue('items', newItems);
  };
  
  // Add tag
  const addTag = (tag: string) => {
    if (tag && !tags.includes(tag)) {
      setTags([...tags, tag]);
      setNewTag('');
    }
  };
  
  // Remove tag
  const removeTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };
  
  // Handle tag input keydown
  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && newTag) {
      e.preventDefault();
      addTag(newTag);
    }
  };
  
  // Handle form submission
  const onSubmit = (formData: ExtractedDocumentData) => {
    // Add tags to form data
    const updatedData = {
      ...formData,
      tags
    };
    
    onUpdate(updatedData);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="vendor"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Vendor</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>
        
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <FormField
            control={form.control}
            name="invoiceNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Invoice/Receipt Number</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="paymentMethod"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Payment Method</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea rows={2} {...field} />
              </FormControl>
            </FormItem>
          )}
        />
        
        <div>
          <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Items</FormLabel>
          
          {items.map((item, index) => (
            <div key={index} className="flex items-center space-x-2 py-2 border-b border-gray-200">
              <Input
                value={item.description}
                onChange={(e) => updateItem(index, 'description', e.target.value)}
                placeholder="Description"
                className="flex-grow"
              />
              <Input
                type="number"
                value={item.quantity}
                onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value, 10))}
                className="w-20"
                min={1}
              />
              <Input
                value={item.price}
                onChange={(e) => updateItem(index, 'price', e.target.value)}
                placeholder="Price"
                className="w-24"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => removeItem(index)}
                className="text-gray-400 hover:text-gray-500"
              >
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          ))}
          
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addItem}
            className="mt-3"
          >
            <Plus className="h-4 w-4 mr-1" /> Add Item
          </Button>
        </div>
        
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <FormField
            control={form.control}
            name="subtotal"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Subtotal</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="tax"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tax</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="total"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Total</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>
        
        <div>
          <FormLabel>Tags</FormLabel>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            {tags.map(tag => (
              <Badge key={tag} variant="secondary" className="px-2.5 py-0.5 text-xs font-medium">
                {tag}
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeTag(tag)}
                  className="ml-1 h-4 w-4 rounded-full p-0"
                >
                  <X className="h-3 w-3" />
                </Button>
              </Badge>
            ))}
            
            <Input
              type="text"
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyDown={handleTagKeyDown}
              placeholder="Add tag..."
              className="inline-flex items-center h-8 px-3 w-32 rounded-md border-0 bg-transparent"
            />
          </div>
        </div>
        
        <div className="mt-6 flex justify-end space-x-3">
          <Button
            type="button"
            variant="outline"
          >
            Save as Draft
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Saving..." : "Complete & Save"}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default ExtractedDataForm;
