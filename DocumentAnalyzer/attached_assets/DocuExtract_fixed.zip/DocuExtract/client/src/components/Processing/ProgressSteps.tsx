import React from 'react';
import { 
  UploadCloud, 
  ScanLine, 
  Bot, 
  Edit, 
  CheckCircle 
} from 'lucide-react';

interface ProgressStepsProps {
  currentStep: 'upload' | 'ocr' | 'ai_processing' | 'review' | 'complete';
}

const ProgressSteps: React.FC<ProgressStepsProps> = ({ currentStep }) => {
  const steps = [
    { id: 'upload', label: 'Upload', description: 'Document uploaded', icon: UploadCloud },
    { id: 'ocr', label: 'OCR', description: 'Text extracted', icon: ScanLine },
    { id: 'ai_processing', label: 'AI Processing', description: 'Extracting data...', icon: Bot },
    { id: 'review', label: 'Review', description: 'Verify extraction', icon: Edit },
    { id: 'complete', label: 'Complete', description: 'Save and export', icon: CheckCircle },
  ];

  // Determine current step index
  const currentIndex = steps.findIndex(step => step.id === currentStep);

  return (
    <div className="flex items-center justify-between">
      <div className="w-full">
        <nav className="flex items-center">
          <ol className="flex items-center w-full">
            {steps.map((step, index) => {
              // Determine if step is active, completed, or upcoming
              const isActive = index === currentIndex;
              const isCompleted = index < currentIndex;
              const isUpcoming = index > currentIndex;
              
              // Dynamic classes based on step status
              const bgColorClass = isCompleted || isActive
                ? 'bg-primary'
                : 'bg-gray-200';
                
              const textColorClass = isCompleted || isActive
                ? 'text-white'
                : 'text-gray-500';
                
              const lineColorClass = isCompleted
                ? 'bg-primary'
                : 'bg-gray-200';
                
              const textFontClass = isActive || isCompleted
                ? 'text-gray-900'
                : 'text-gray-500';
                
              // Add pulse animation for current step
              const animationClass = isActive && currentStep === 'ai_processing'
                ? 'animate-pulse'
                : '';
              
              const Icon = step.icon;
              
              return (
                <li key={step.id} className="relative flex-1">
                  <div className="flex items-center">
                    <div className={`flex-shrink-0 h-10 w-10 flex items-center justify-center ${bgColorClass} rounded-full ${textColorClass} ${animationClass}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="hidden md:block ml-4">
                      <p className={`text-sm font-medium ${textFontClass}`}>{step.label}</p>
                      <p className="text-xs text-gray-500">{step.description}</p>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div 
                      className={`hidden md:block absolute top-5 right-0 w-full h-0.5 ${lineColorClass}`}
                    />
                  )}
                </li>
              );
            })}
          </ol>
        </nav>
      </div>
    </div>
  );
};

export default ProgressSteps;
