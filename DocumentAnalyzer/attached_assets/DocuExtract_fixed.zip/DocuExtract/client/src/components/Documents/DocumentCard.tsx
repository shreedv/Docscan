import React from 'react';
import { Document } from '@/lib/types';
import { Link } from 'wouter';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Eye, MoreHorizontal, Download } from 'lucide-react';
import { format } from 'date-fns';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';

interface DocumentCardProps {
  document: Document;
}

const DocumentCard: React.FC<DocumentCardProps> = ({ document }) => {
  const { id, extractedData, confidence, tags, createdAt } = document;
  
  // Format date
  const formattedDate = createdAt ? format(new Date(createdAt), 'MMM d, yyyy') : 'Unknown date';
  
  return (
    <Card className="overflow-hidden flex flex-col h-full">
      <CardHeader className="bg-gray-50 border-b pb-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <div className="bg-gray-200 rounded p-2 mr-3">
              <FileText className="h-5 w-5 text-gray-500" />
            </div>
            <div>
              <CardTitle className="text-base truncate">
                {document.fileName || extractedData.vendor || "Untitled Document"}
              </CardTitle>
              <div className="text-xs text-gray-500 mt-1">
                {formattedDate}
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Link href={`/process/${id}`}>
                  <div className="flex items-center w-full">
                    <Eye className="mr-2 h-4 w-4" /> View Details
                  </div>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="mr-2 h-4 w-4" /> Download PDF
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                <i className="ri-delete-bin-line mr-2"></i> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      
      <CardContent className="py-4 flex-grow">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <div className="text-sm font-medium">Vendor:</div>
            <div className="text-sm text-gray-700 truncate max-w-[180px]">
              {extractedData.vendor || "Unknown"}
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-sm font-medium">Total:</div>
            <div className="text-sm text-gray-700">{extractedData.total || "$0.00"}</div>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-sm font-medium">Invoice #:</div>
            <div className="text-sm text-gray-700 truncate max-w-[180px]">
              {extractedData.invoiceNumber || "N/A"}
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-sm font-medium">Confidence:</div>
            <Badge variant="outline" className={`${
              (confidence || 0) > 90 ? 'text-green-600 bg-green-50' : 
              (confidence || 0) > 75 ? 'text-amber-600 bg-amber-50' : 
              'text-red-600 bg-red-50'
            }`}>
              {confidence || 0}%
            </Badge>
          </div>
        </div>
        
        {tags && tags.length > 0 && (
          <div className="mt-4">
            <div className="text-xs font-medium text-gray-500 mb-2">Tags:</div>
            <div className="flex flex-wrap gap-1">
              {tags.map((tag, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="pt-2 pb-4 px-6 border-t flex justify-between">
        <Link href={`/process/${id}`}>
          <Button variant="outline" size="sm">
            <Eye className="mr-2 h-3 w-3" /> View
          </Button>
        </Link>
        <Button variant="outline" size="sm">
          <Download className="mr-2 h-3 w-3" /> Download
        </Button>
      </CardFooter>
    </Card>
  );
};

export default DocumentCard;
