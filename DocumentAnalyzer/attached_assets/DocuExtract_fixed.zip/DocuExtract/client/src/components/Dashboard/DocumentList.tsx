import React from 'react';
import { Link } from 'wouter';
import { MoreHorizontal, FileText } from 'lucide-react';
import { Document } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';

interface DocumentListProps {
  documents: Document[];
  isLoading?: boolean;
}

const DocumentList: React.FC<DocumentListProps> = ({ documents, isLoading }) => {
  if (isLoading) {
    return (
      <div className="divide-y divide-gray-200">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="p-4 sm:px-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center min-w-0">
                <Skeleton className="h-10 w-10 rounded" />
                <div className="ml-4 space-y-2">
                  <Skeleton className="h-4 w-48" />
                  <Skeleton className="h-3 w-32" />
                </div>
              </div>
              <Skeleton className="h-6 w-24 rounded-full" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!documents || documents.length === 0) {
    return (
      <div className="py-8 text-center">
        <FileText className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">No documents</h3>
        <p className="mt-1 text-sm text-gray-500">
          Start by uploading a document for processing.
        </p>
        <div className="mt-6">
          <Link href="/upload">
            <Button>Upload a document</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="divide-y divide-gray-200">
      {documents.map((document) => {
        const data = document.extractedData;
        
        // Format the date for display
        let displayDate = "Unknown date";
        try {
          if (data.date) {
            displayDate = format(new Date(data.date), 'MMM d, yyyy');
          } else if (document.createdAt) {
            displayDate = format(new Date(document.createdAt), 'MMM d, yyyy');
          }
        } catch (e) {
          console.error("Date format error:", e);
        }
        
        return (
          <div key={document.id} className="p-4 sm:px-6 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center min-w-0">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded bg-gray-200 flex items-center justify-center text-gray-500">
                    <FileText className="h-5 w-5" />
                  </div>
                </div>
                <div className="ml-4 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {document.fileName || data.vendor || "Untitled Document"}
                  </p>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <span>Vendor: {data.vendor || "Unknown"}</span>
                    <span className="mx-2">•</span>
                    <span>{data.total || "$0.00"}</span>
                    <span className="mx-2">•</span>
                    <span>{displayDate}</span>
                  </div>
                </div>
              </div>
              <div className="ml-4 flex items-center">
                <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                  {document.confidence || 95}% confidence
                </span>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="ml-2 text-gray-400 hover:text-gray-500">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Link href={`/process/${document.id}`}>
                        View Details
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>Download PDF</DropdownMenuItem>
                    <DropdownMenuItem>Delete</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DocumentList;
