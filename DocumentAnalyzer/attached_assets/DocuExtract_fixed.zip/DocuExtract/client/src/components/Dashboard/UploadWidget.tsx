import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Link, useLocation } from 'wouter';
import { UploadCloud, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface UploadWidgetProps {
  className?: string;
  onUpload?: (file: File) => void;
  inline?: boolean;
}

const UploadWidget: React.FC<UploadWidgetProps> = ({ 
  className, 
  onUpload,
  inline
}) => {
  const [, setLocation] = useLocation();
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      
      if (onUpload) {
        onUpload(file);
      } else {
        // If no onUpload callback provided, navigate to the processing page
        setLocation(`/process?file=${encodeURIComponent(file.name)}`);
      }
    }
  }, [onUpload, setLocation]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'application/pdf': ['.pdf'],
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: false
  });

  // If inline mode (for buttons)
  if (inline) {
    // Don't wrap in button element since it will be used inside a button
    return (
      <div {...getRootProps()} className={className}>
        <input {...getInputProps()} />
        <UploadCloud className="h-4 w-4" />
      </div>
    );
  }

  // Full upload widget mode
  return (
    <div className="w-full">
      <div 
        {...getRootProps()} 
        className={`bg-gray-50 border-2 border-dashed ${isDragActive ? 'border-primary' : 'border-gray-300'} rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50/80 transition-colors ${className}`}
      >
        <input {...getInputProps()} />
        <div className="flex justify-center">
          <UploadCloud className="h-10 w-10 text-gray-400" />
        </div>
        <p className="mt-2 text-sm font-medium text-gray-900">
          {isDragActive 
            ? "Drop your document here" 
            : "Drop your document here or click to browse"}
        </p>
        <p className="text-xs text-gray-500">
          Supports: JPG, PNG, PDF (max. 10MB)
        </p>
        
        <div className="mt-4">
          <span className="inline-block px-4 py-2 text-xs font-medium text-primary bg-primary/10 rounded-full">
            Browse Files
          </span>
        </div>

        {uploadProgress !== null && (
          <div className="mt-4">
            <div className="w-full h-2 bg-gray-200 rounded-full">
              <div 
                className="h-2 bg-primary rounded-full" 
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <p className="mt-1 text-xs text-gray-500 text-center">
              Uploading: {uploadProgress}%
            </p>
          </div>
        )}
      </div>
      
      <div className="mt-4">
        <Button variant="outline" className="w-full" size="sm">
          <Camera className="mr-2 h-4 w-4" /> Capture with Camera
        </Button>
      </div>
    </div>
  );
};

export default UploadWidget;
