import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Document } from '@/lib/types';
import DocumentList from '@/components/Dashboard/DocumentList';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Search, Upload, Filter } from 'lucide-react';

const Documents: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'amount'>('newest');
  
  // Fetch all documents
  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ['/api/documents'],
  });

  // Filter documents based on search term
  const filteredDocuments = documents?.filter(doc => {
    const searchLower = searchTerm.toLowerCase();
    return (
      doc.fileName?.toLowerCase().includes(searchLower) ||
      doc.extractedData.vendor?.toLowerCase().includes(searchLower) ||
      doc.extractedData.invoiceNumber?.toLowerCase().includes(searchLower) ||
      doc.extractedData.description?.toLowerCase().includes(searchLower) ||
      doc.tags?.some(tag => tag.toLowerCase().includes(searchLower))
    );
  });

  // Sort documents based on selected sort order
  const sortedDocuments = React.useMemo(() => {
    if (!filteredDocuments) return [];
    
    return [...filteredDocuments].sort((a, b) => {
      if (sortOrder === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      } else if (sortOrder === 'oldest') {
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      } else if (sortOrder === 'amount') {
        const aTotal = parseFloat(a.extractedData.total.replace(/[^0-9.-]+/g, '')) || 0;
        const bTotal = parseFloat(b.extractedData.total.replace(/[^0-9.-]+/g, '')) || 0;
        return bTotal - aTotal;
      }
      return 0;
    });
  }, [filteredDocuments, sortOrder]);

  return (
    <div className="mt-8 md:mt-0 px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">My Documents</h1>
          <p className="mt-1 text-sm text-gray-500">View and manage your processed documents</p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Link href="/upload">
            <Button>
              <Upload className="mr-2 h-4 w-4" /> Upload New
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Search and filter */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <Input
            type="text"
            placeholder="Search documents..."
            className="pl-10 pr-4 py-2"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
        </div>
        
        <div className="flex items-center">
          <Filter className="mr-2 h-4 w-4 text-gray-500" />
          <Select
            value={sortOrder}
            onValueChange={(value: 'newest' | 'oldest' | 'amount') => setSortOrder(value)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest first</SelectItem>
              <SelectItem value="oldest">Oldest first</SelectItem>
              <SelectItem value="amount">Amount (high to low)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Main content */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
          <h3 className="text-lg font-medium leading-6 text-gray-900">Documents</h3>
        </div>
        
        <DocumentList
          documents={sortedDocuments}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
};

export default Documents;
