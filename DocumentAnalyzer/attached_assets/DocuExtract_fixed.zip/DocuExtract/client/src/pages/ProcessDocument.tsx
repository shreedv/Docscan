import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import ProgressSteps from '@/components/Processing/ProgressSteps';
import ExtractedDataForm from '@/components/Processing/ExtractedDataForm';
import { Document, DocumentProcessingState, ExtractedDocumentData } from '@/lib/types';
import { XIcon } from 'lucide-react';

const ProcessDocument: React.FC = () => {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [processingState, setProcessingState] = useState<DocumentProcessingState>({
    step: id ? 'review' : 'upload',
  });
  
  // Fetch document if ID is provided
  const { data: document, isLoading } = useQuery<Document>({
    queryKey: [`/api/documents/${id}`],
    enabled: !!id,
  });
  
  // Update document mutation
  const updateDocumentMutation = useMutation({
    mutationFn: async (updatedData: ExtractedDocumentData) => {
      return apiRequest('PUT', `/api/documents/${id}`, {
        extractedData: updatedData
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/documents/${id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/documents/recent'] });
      
      toast({
        title: "Document Updated",
        description: "Your changes have been saved successfully."
      });
      
      setLocation('/');
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message || "There was an error updating the document.",
        variant: "destructive"
      });
    }
  });
  
  // Effect to update state when document is loaded
  useEffect(() => {
    if (document) {
      setProcessingState({
        step: 'review',
        extractedData: document.extractedData,
        confidence: document.confidence,
        documentId: document.id
      });
    }
  }, [document]);
  
  const handleUpdateDocument = (updatedData: ExtractedDocumentData) => {
    updateDocumentMutation.mutate(updatedData);
  };
  
  const handleCancel = () => {
    setLocation('/');
  };
  
  if (isLoading && id) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-4xl mx-auto">
          <CardContent className="pt-6">
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Document Processing</h1>
          <p className="mt-1 text-sm text-gray-500">Extract information from your document</p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Button
            variant="outline"
            onClick={handleCancel}
          >
            <XIcon className="mr-2 h-4 w-4" /> Cancel
          </Button>
        </div>
      </div>
      
      {/* Progress steps */}
      <div className="mb-8">
        <ProgressSteps currentStep={processingState.step} />
      </div>
      
      {/* Main content area */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Document preview */}
        <Card>
          <CardHeader>
            <CardTitle>Document Preview</CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center">
            {document?.originalFile ? (
              <div className="relative bg-gray-100 w-full max-w-lg h-96 rounded-lg border border-gray-300 flex items-center justify-center overflow-hidden">
                <img 
                  src={`/api/documents/${id}/preview`} 
                  alt="Document Preview" 
                  className="max-w-full max-h-full object-contain"
                  onError={(e) => {
                    e.currentTarget.src = '';
                    e.currentTarget.alt = 'Preview not available';
                    e.currentTarget.style.display = 'none';
                  }}
                />
                <div className="text-center absolute inset-0 flex items-center justify-center">
                  <div>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="text-gray-400 w-16 h-16 mx-auto">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                    </svg>
                    <p className="mt-2 text-sm text-gray-500">
                      {document?.fileName || 'Document Preview'}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-gray-100 w-full max-w-lg h-96 rounded-lg border border-gray-300 flex items-center justify-center">
                <div className="text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="text-gray-400 w-16 h-16 mx-auto">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>
                  <p className="mt-2 text-sm text-gray-500">
                    Document Preview Not Available
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Extracted data form */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Extracted Information</CardTitle>
              <CardDescription>Review and edit the extracted data</CardDescription>
            </div>
            {processingState.confidence && (
              <div className="text-sm text-gray-500">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full bg-green-100 text-green-800">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {processingState.confidence}% confidence
                </span>
              </div>
            )}
          </CardHeader>
          <CardContent>
            {processingState.extractedData ? (
              <ExtractedDataForm 
                data={processingState.extractedData} 
                onUpdate={handleUpdateDocument}
                isSubmitting={updateDocumentMutation.isPending}
              />
            ) : (
              <div className="flex items-center justify-center h-64">
                <div className="text-center">
                  <p className="text-gray-500">No data available</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProcessDocument;
