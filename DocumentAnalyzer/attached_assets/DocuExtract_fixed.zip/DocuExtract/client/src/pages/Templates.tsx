import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Template } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter,
  DialogTrigger 
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormDescription
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { PlusCircle, FileText, MoreHorizontal, Edit, Trash } from 'lucide-react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';

// Template create/edit form schema
const templateFormSchema = z.object({
  name: z.string().min(2, { message: "Template name is required" }),
  description: z.string().optional(),
  fields: z.any() // In a real app, we'd validate the fields structure
});

type TemplateFormValues = z.infer<typeof templateFormSchema>;

const Templates: React.FC = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch templates
  const { data: templates, isLoading } = useQuery<Template[]>({
    queryKey: ['/api/templates'],
  });
  
  // Create template mutation
  const createTemplateMutation = useMutation({
    mutationFn: async (template: TemplateFormValues) => {
      // Convert to proper template format
      const newTemplate = {
        ...template,
        fields: {
          vendor: "string",
          date: "date",
          invoiceNumber: "string",
          total: "number",
          tax: "number",
          items: "array",
          ...((typeof template.fields === 'object') ? template.fields : {})
        }
      };
      
      return apiRequest('POST', '/api/templates', newTemplate);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      setIsDialogOpen(false);
      toast({
        title: "Template Created",
        description: "Your new template has been created successfully."
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to Create Template",
        description: error.message || "There was an error creating the template.",
        variant: "destructive"
      });
    }
  });
  
  // Form setup
  const form = useForm<TemplateFormValues>({
    resolver: zodResolver(templateFormSchema),
    defaultValues: {
      name: "",
      description: "",
      fields: {
        vendor: "string",
        date: "date",
        invoiceNumber: "string",
        total: "number",
        tax: "number",
        items: "array"
      }
    }
  });
  
  // Form submission handler
  const onSubmit = (data: TemplateFormValues) => {
    createTemplateMutation.mutate(data);
  };
  
  return (
    <div className="mt-8 md:mt-0 px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Document Templates</h1>
          <p className="mt-1 text-sm text-gray-500">Create and manage templates for different document types</p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="mr-2 h-4 w-4" /> New Template
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create New Template</DialogTitle>
                <DialogDescription>
                  Define a template for a specific document type to improve extraction accuracy.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Template Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Invoice Template" {...field} />
                        </FormControl>
                        <FormDescription>
                          A descriptive name for this template type
                        </FormDescription>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="e.g. For processing vendor invoices" 
                            {...field} 
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={createTemplateMutation.isPending}
                    >
                      {createTemplateMutation.isPending ? "Creating..." : "Create Template"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Templates grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          // Loading skeletons
          Array.from({ length: 3 }).map((_, index) => (
            <Card key={index} className="h-[200px] animate-pulse">
              <CardHeader className="bg-gray-100">
                <div className="h-6 w-3/4 bg-gray-200 rounded"></div>
                <div className="h-4 w-1/2 bg-gray-200 rounded mt-2"></div>
              </CardHeader>
              <CardContent className="px-6 py-4 flex-grow">
                <div className="h-4 w-full bg-gray-100 rounded mb-2"></div>
                <div className="h-4 w-3/4 bg-gray-100 rounded mb-2"></div>
                <div className="h-4 w-1/2 bg-gray-100 rounded"></div>
              </CardContent>
            </Card>
          ))
        ) : (
          // Actual templates
          templates?.map(template => (
            <Card key={template.id} className="flex flex-col">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{template.name}</CardTitle>
                    <CardDescription className="mt-1">{template.description}</CardDescription>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" /> Edit Template
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-red-600">
                        <Trash className="mr-2 h-4 w-4" /> Delete Template
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="px-6 py-2 flex-grow">
                <div className="text-sm text-gray-500">
                  <div className="mb-2">
                    <strong>Supported Fields:</strong>
                  </div>
                  <ul className="space-y-1">
                    {template.fields && Object.entries(template.fields).map(([key, type]) => (
                      <li key={key} className="flex items-center">
                        <span className="w-2 h-2 rounded-full bg-primary mr-2"></span>
                        <span className="capitalize">{key}</span>
                        <span className="text-xs text-gray-400 ml-1">({type})</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
              <CardFooter className="border-t px-6 py-4">
                <Button variant="outline" size="sm" className="w-full">
                  <FileText className="mr-2 h-4 w-4" /> Use Template
                </Button>
              </CardFooter>
            </Card>
          ))
        )}
      </div>
      
      {templates?.length === 0 && !isLoading && (
        <div className="text-center py-10">
          <FileText className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No templates</h3>
          <p className="mt-1 text-sm text-gray-500">
            Get started by creating a new document template.
          </p>
          <div className="mt-6">
            <Button onClick={() => setIsDialogOpen(true)}>
              <PlusCircle className="mr-2 h-4 w-4" /> Create New Template
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Templates;
