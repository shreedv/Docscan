import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import StatCard from '@/components/Dashboard/StatCard';
import DocumentList from '@/components/Dashboard/DocumentList';
import UploadWidget from '@/components/Dashboard/UploadWidget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Search, Plus, CreditCard, FileText, Lightbulb, UploadCloud } from 'lucide-react';
import { DashboardStats, Document } from '@/lib/types';

const Dashboard = () => {
  // Fetch dashboard stats
  const { data: stats, isLoading: isLoadingStats } = useQuery<DashboardStats>({
    queryKey: ['/api/stats'],
  });

  // Fetch recent documents
  const { data: documents, isLoading: isLoadingDocuments } = useQuery<Document[]>({
    queryKey: ['/api/documents/recent'],
  });

  // Fetch templates for the sidebar
  const { data: templates } = useQuery<any[]>({
    queryKey: ['/api/templates'],
  });

  return (
    <div className="mt-8 md:mt-0 px-4 py-6 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">Manage your documents and processing history</p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center">
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search documents..." 
              className="pl-10 pr-4 py-2"
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
          </div>
          
          <Link href="/upload">
            <Button className="ml-4">
              <UploadCloud className="mr-2 h-4 w-4" /> Upload
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Stats cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Processed Documents"
          value={isLoadingStats ? "Loading..." : `${stats?.processedCount}`}
          icon={<FileText className="text-primary" />}
          change="+12%"
          changeText="from last month"
          isPositive={true}
        />
        
        <StatCard 
          title="Time Saved"
          value={isLoadingStats ? "Loading..." : `${stats?.timeSaved || 0} hrs`}
          icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="text-green-600">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>}
          change="+8%"
          changeText="from last month"
          isPositive={true}
          iconBgClass="bg-green-100"
        />
        
        <StatCard 
          title="Avg. Accuracy"
          value={isLoadingStats ? "Loading..." : `${stats?.avgConfidence || 0}%`}
          icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="text-blue-600">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
          </svg>}
          change="+2.1%"
          changeText="from last month"
          isPositive={true}
          iconBgClass="bg-blue-100"
        />
        
        <StatCard 
          title="Templates Used"
          value={isLoadingStats ? "Loading..." : `${stats?.templatesCount || 0}`}
          icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="text-purple-600">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.776c.112-.017.227-.026.344-.026h15.812c.117 0 .232.009.344.026m-16.5 0a2.25 2.25 0 00-1.883 2.542l.857 6a2.25 2.25 0 002.227 1.932H19.05a2.25 2.25 0 002.227-1.932l.857-6a2.25 2.25 0 00-1.883-2.542m-16.5 0V6A2.25 2.25 0 016 3.75h3.879a1.5 1.5 0 011.06.44l2.122 2.12a1.5 1.5 0 001.06.44H18A2.25 2.25 0 0120.25 9v.776" />
          </svg>}
          change="+1"
          changeText="new this month"
          isPositive={true}
          iconBgClass="bg-purple-100"
        />
      </div>
      
      {/* Main section */}
      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Recently processed documents */}
        <div className="lg:col-span-2">
          <Card>
            <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Recently Processed Documents</h3>
            </div>
            
            <DocumentList 
              documents={documents || []} 
              isLoading={isLoadingDocuments} 
            />
            
            <div className="px-6 py-4 border-t border-gray-200">
              <Link href="/documents">
                <div className="text-sm font-medium text-primary hover:text-primary/90">
                  View all documents →
                </div>
              </Link>
            </div>
          </Card>
          
          {/* Document history chart */}
          <Card className="mt-6">
            <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Processing Activity</h3>
            </div>
            <div className="p-4 sm:p-6">
              <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center border border-dashed border-gray-300">
                <div className="text-center">
                  <p className="text-gray-500">Chart showing document processing history over time</p>
                  <p className="text-xs text-gray-400 mt-1">Activity visualization would be implemented with Recharts</p>
                </div>
              </div>
            </div>
          </Card>
        </div>
        
        {/* Right sidebar */}
        <div className="lg:col-span-1 space-y-6">
          {/* Upload widget */}
          <Card>
            <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Quick Upload</h3>
            </div>
            <div className="p-6">
              <UploadWidget />
            </div>
          </Card>
          
          {/* Template selection widget */}
          <Card>
            <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Templates</h3>
            </div>
            
            <ul className="divide-y divide-gray-200">
              {templates && templates.length > 0 ? templates.slice(0, 3).map((template: any) => (
                <li key={template.id}>
                  <Link href={`/upload?templateId=${template.id}`}>
                    <div className="flex items-center px-4 py-4 hover:bg-gray-50 sm:px-6">
                      <div className="min-w-0 flex-1 flex items-center">
                        <div className={`flex-shrink-0 ${
                          template.id % 3 === 0 ? 'bg-primary/10' : 
                          template.id % 3 === 1 ? 'bg-blue-100' : 'bg-green-100'
                        } rounded p-2`}>
                          <FileText className={`h-5 w-5 ${
                            template.id % 3 === 0 ? 'text-primary' : 
                            template.id % 3 === 1 ? 'text-blue-600' : 'text-green-600'
                          }`} />
                        </div>
                        <div className="min-w-0 flex-1 px-4">
                          <div>
                            <p className="text-sm font-medium text-primary truncate">{template.name}</p>
                            <p className="mt-1 text-xs text-gray-500">{template.description}</p>
                          </div>
                        </div>
                      </div>
                      <div className="ml-5 flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-400">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                        </svg>
                      </div>
                    </div>
                  </Link>
                </li>
              )) : null}
            </ul>
            
            <div className="px-4 py-4 border-t border-gray-200 sm:px-6">
              <Link href="/templates">
                <div className="text-sm font-medium text-primary hover:text-primary/90">
                  Create new template <Plus className="ml-1 inline-block h-4 w-4" />
                </div>
              </Link>
            </div>
          </Card>
          
          {/* Quick tips */}
          <Card>
            <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Tips & Tricks</h3>
            </div>
            <div className="p-4 sm:p-6">
              <ul className="space-y-4">
                <li className="flex">
                  <div className="flex-shrink-0">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                  </div>
                  <p className="ml-3 text-sm text-gray-600">
                    Ensure good lighting when capturing photos of documents for better OCR accuracy.
                  </p>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                  </div>
                  <p className="ml-3 text-sm text-gray-600">
                    Tag your documents to easily filter and find them later in your archive.
                  </p>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                  </div>
                  <p className="ml-3 text-sm text-gray-600">
                    Create custom templates for recurring document types to speed up processing.
                  </p>
                </li>
              </ul>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
