import React, { useState, useCallback, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { UploadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Template } from '@/lib/types';
import UploadWidget from '@/components/Dashboard/UploadWidget';
import { FileText, ArrowRight, Scan } from 'lucide-react';

const Upload: React.FC = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isUploading, setIsUploading] = useState(false);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [uploadMethod, setUploadMethod] = useState<string>("file");
  const [isProcessing, setIsProcessing] = useState(false);
  const [ocrProgress, setOcrProgress] = useState<number>(0);

  // Fetch templates
  const { data: templates } = useQuery<Template[]>({
    queryKey: ['/api/templates'],
  });

  const handleFileUpload = useCallback((file: File) => {
    setSelectedFile(file);
  }, []);

  // Reset progress when file changes
  useEffect(() => {
    setOcrProgress(0);
  }, [selectedFile]);

  // Create mutation for saving processed document
  const saveDocumentMutation = useMutation({
    mutationFn: async (documentData: any) => {
      return await apiRequest('/api/documents/save', {
        method: 'POST',
        body: documentData
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      queryClient.invalidateQueries({ queryKey: ['/api/documents/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });

      toast({
        title: "Processing Successful",
        description: "Your document has been processed successfully.",
      });

      // Navigate to the document review page
      setLocation(`/process/${data.document.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Processing Failed",
        description: error.message || "There was an error saving your document.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedFile) {
      toast({
        title: "Error",
        description: "Please select a document to upload",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsProcessing(true);

      // Create FormData for file upload
      const formData = new FormData();
      formData.append('file', selectedFile);

      // 1. Upload file
      const uploadResponse = await fetch('/api/documents/process', {
        method: 'POST',
        body: formData
      });

      if (!uploadResponse.ok) {
        throw new Error('File upload failed');
      }

      const uploadResult = await uploadResponse.json();

      // 2. Extract text using Tesseract.js
      toast({
        title: "Processing Document",
        description: "Extracting text from your document...",
      });

      const extractedText = await extractTextFromImage(
        selectedFile, 
        (progress) => setOcrProgress(progress * 100)
      );

      if (!extractedText || extractedText.trim() === '') {
        throw new Error("Could not extract text from the document");
      }

      // 3. Save processed data
      await saveDocumentMutation.mutateAsync({
        extractedText,
        extractedData: {
          vendor: '',
          date: '',
          invoiceNumber: '',
          total: '0',
          subtotal: '0',
          items: []
        },
        confidence: 0,
        fileName: selectedFile.name,
        templateId: selectedTemplate !== "auto" ? parseInt(selectedTemplate) : undefined,
        originalFile: uploadResult.filePath
      });

    } catch (error: any) {
      console.error('Processing error:', error);
      toast({
        title: "Processing Failed",
        description: error.message || "There was an error processing your document.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Upload Document</h1>
          <p className="mt-1 text-sm text-gray-500">
            Upload a receipt or invoice to extract data automatically
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Document Upload</CardTitle>
              <CardDescription>
                Choose a document to process with our AI-powered extraction
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                {/* Upload methods */}
                <div className="mb-6">
                  <Label className="text-base font-medium">Upload Method</Label>
                  <RadioGroup
                    value={uploadMethod}
                    onValueChange={setUploadMethod}
                    className="flex flex-col space-y-1 mt-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="file" id="file" />
                      <Label htmlFor="file">File Upload</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="camera" id="camera" />
                      <Label htmlFor="camera">Camera Capture</Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* File upload area */}
                <div className="mb-6">
                  <Label className="text-base font-medium mb-2 block">
                    Upload Document
                  </Label>
                  <UploadWidget onUpload={handleFileUpload} />

                  {selectedFile && (
                    <div className="mt-4 p-3 bg-gray-50 rounded-md border border-gray-200">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-gray-400 mr-2" />
                        <div className="text-sm font-medium text-gray-700 truncate">
                          {selectedFile.name}
                        </div>
                        <div className="ml-2 text-xs text-gray-500">
                          ({Math.round(selectedFile.size / 1024)}KB)
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Template selection */}
                <div className="mb-6">
                  <Label htmlFor="template" className="text-base font-medium block mb-2">
                    Document Template
                  </Label>
                  <Select
                    value={selectedTemplate}
                    onValueChange={setSelectedTemplate}
                  >
                    <SelectTrigger id="template">
                      <SelectValue placeholder="Select a template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto-detect (recommended)</SelectItem>
                      {templates?.map(template => (
                        <SelectItem key={template.id} value={template.id.toString()}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="mt-1 text-xs text-gray-500">
                    Templates help improve extraction accuracy for specific document types
                  </p>
                </div>

                {/* OCR Progress indicator */}
                {isProcessing && ocrProgress > 0 && (
                  <div className="mb-6">
                    <div className="flex justify-between mb-2">
                      <Label className="text-sm font-medium">Processing document</Label>
                      <span className="text-xs text-gray-500">{Math.round(ocrProgress)}%</span>
                    </div>
                    <Progress value={ocrProgress} className="h-2" />
                    <p className="mt-1 text-xs text-gray-500">
                      Extracting text from your document using OCR...
                    </p>
                  </div>
                )}

                <div className="flex justify-end">
                  <Button
                    type="submit"
                    disabled={!selectedFile || isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Scan className="mr-2 h-4 w-4 animate-pulse" />
                        Processing...
                      </>
                    ) : (
                      <>
                        Process Document
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Document Tips</CardTitle>
              <CardDescription>
                Follow these tips for best results
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                <li className="flex">
                  <div className="flex-shrink-0 h-5 w-5 text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <p className="ml-3 text-sm text-gray-600">
                    Ensure good lighting and a clear view of the entire document.
                  </p>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0 h-5 w-5 text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <p className="ml-3 text-sm text-gray-600">
                    Remove any objects casting shadows on the document.
                  </p>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0 h-5 w-5 text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <p className="ml-3 text-sm text-gray-600">
                    For best results, use the original digital document if available.
                  </p>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0 h-5 w-5 text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <p className="ml-3 text-sm text-gray-600">
                    Choose the appropriate template for your document type.
                  </p>
                </li>
              </ul>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <h4 className="font-medium text-gray-900">Supported File Types</h4>
                <ul className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 text-sm text-gray-500">
                  <li className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="mr-2 h-4 w-4 text-primary">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    JPG/JPEG
                  </li>
                  <li className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="mr-2 h-4 w-4 text-primary">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    PNG
                  </li>
                  <li className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="mr-2 h-4 w-4 text-primary">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    PDF
                  </li>
                  <li className="flex items-center opacity-50">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="mr-2 h-4 w-4 text-gray-400">
                      <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                    TIFF (coming soon)
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Upload;