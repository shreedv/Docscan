import { createWorker } from 'tesseract.js';

// Define a workaround type for the Tesseract worker
interface TesseractWorker {
  load: () => Promise<any>;
  loadLanguage: (lang: string) => Promise<any>;
  initialize: (lang: string) => Promise<any>;
  recognize: (image: string) => Promise<{ data: { text: string } }>;
  terminate: () => Promise<any>;
}

/**
 * Extract text from an image using Tesseract.js
 * @param imageFile The image file to process
 * @param progressCallback Optional callback for progress updates
 * @returns Promise with extracted text
 */
export async function extractTextFromImage(
  imageFile: File,
  progressCallback?: (progress: number) => void
): Promise<string> {
  try {
    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!validTypes.includes(imageFile.type)) {
      throw new Error(`Unsupported file type: ${imageFile.type}. Please use JPG, PNG, or PDF files.`);
    }

    // Create worker with progress logging
    const worker = await createWorker({
      logger: m => {
        console.log('OCR Progress:', m);
        if (progressCallback && m.status === 'recognizing text') {
          progressCallback(m.progress);
        }
      }
    }) as unknown as TesseractWorker;

    // Initialize worker with English language
    await worker.loadLanguage('eng');
    await worker.initialize('eng');

    // Convert file to base64
    const base64Image = await fileToBase64(imageFile);
    
    // Recognize text
    const { data } = await worker.recognize(base64Image);
    
    // Validate extracted text
    if (!data.text || data.text.trim().length === 0) {
      throw new Error('No text could be extracted from the image. Please ensure the image is clear and contains readable text.');
    }
    
    // Terminate worker
    await worker.terminate();
    
    return data.text;
  } catch (error) {
    console.error('OCR processing error:', error);
    throw new Error('Failed to extract text from image');
  }
}

/**
 * Parse receipt or invoice text to extract relevant fields
 * This is a simple rule-based extraction for common receipt/invoice fields
 * @param text The extracted text from OCR
 * @returns Extracted data object
 */
export function extractDocumentData(text: string): {
  data: any;
  confidence: number;
} {
  // Convert text to lowercase and split into lines for processing
  const lines = text.split('\n').filter(line => line.trim().length > 0);
  const lowerText = text.toLowerCase();

  // Initialize data structure with default values
  const data = {
    vendor: '',
    date: '',
    invoiceNumber: '',
    paymentMethod: '',
    description: '',
    subtotal: '',
    tax: '',
    total: '',
    items: [] as { description: string; quantity: number; price: string }[]
  };

  // Extract vendor name (usually in the first few lines)
  if (lines.length > 0) {
    data.vendor = lines[0].trim();
  }

  // Look for date patterns (MM/DD/YYYY or similar)
  const dateRegex = /\b(0?[1-9]|1[0-2])[\/\-](0?[1-9]|[12]\d|3[01])[\/\-](19|20)?\d{2}\b/;
  const dateMatch = text.match(dateRegex);
  if (dateMatch) {
    data.date = dateMatch[0];
  }

  // Look for invoice/receipt number
  const invoiceRegex = /\b(invoice|receipt)[\s#:]*([a-z0-9\-]+)\b/i;
  const invoiceMatch = text.match(invoiceRegex);
  if (invoiceMatch) {
    data.invoiceNumber = invoiceMatch[2];
  }

  // Look for payment method
  if (lowerText.includes('visa') || lowerText.includes('mastercard') || lowerText.includes('credit card')) {
    data.paymentMethod = 'Credit Card';
  } else if (lowerText.includes('cash')) {
    data.paymentMethod = 'Cash';
  } else if (lowerText.includes('paypal')) {
    data.paymentMethod = 'PayPal';
  }

  // Extract total amount
  const totalRegex = /\b(total|amount|sum)[\s:]*[$€£]?([0-9,]+\.[0-9]{2})\b/i;
  const totalMatch = text.match(totalRegex);
  if (totalMatch) {
    data.total = totalMatch[2];
  }

  // Extract subtotal if available
  const subtotalRegex = /\b(subtotal|sub-total|net)[\s:]*[$€£]?([0-9,]+\.[0-9]{2})\b/i;
  const subtotalMatch = text.match(subtotalRegex);
  if (subtotalMatch) {
    data.subtotal = subtotalMatch[2];
  }

  // Extract tax amount
  const taxRegex = /\b(tax|vat|gst)[\s:]*[$€£]?([0-9,]+\.[0-9]{2})\b/i;
  const taxMatch = text.match(taxRegex);
  if (taxMatch) {
    data.tax = taxMatch[2];
  }

  // Try to extract line items (this is more complex and may need improvement)
  // Simple pattern: look for lines with both numbers and text that might be items
  const itemRegex = /(.+?)\s+([0-9]+)\s+[$€£]?([0-9,]+\.[0-9]{2})/;
  
  for (const line of lines) {
    const itemMatch = line.match(itemRegex);
    if (itemMatch && !line.toLowerCase().includes('total') && !line.toLowerCase().includes('subtotal')) {
      data.items.push({
        description: itemMatch[1].trim(),
        quantity: parseInt(itemMatch[2], 10),
        price: itemMatch[3]
      });
    }
  }

  // Calculate a simple confidence score
  // Higher if we found more fields
  let fieldsFound = 0;
  let totalFields = 7; // Excluding items array
  
  if (data.vendor) fieldsFound++;
  if (data.date) fieldsFound++;
  if (data.invoiceNumber) fieldsFound++;
  if (data.paymentMethod) fieldsFound++;
  if (data.subtotal) fieldsFound++;
  if (data.tax) fieldsFound++;
  if (data.total) fieldsFound++;
  
  const confidence = Math.round((fieldsFound / totalFields) * 100);

  return {
    data,
    confidence
  };
}

/**
 * Convert a file to base64 string
 * @param file File to convert
 * @returns Promise with base64 string
 */
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
}