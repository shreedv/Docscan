export interface User {
  id: number;
  username: string;
}

export interface Template {
  id: number;
  name: string;
  description: string;
  fields: Record<string, string>;
  createdAt: Date;
}

export interface DocumentItem {
  description: string;
  quantity: number;
  price: string;
}

export interface ExtractedDocumentData {
  vendor: string;
  date: string;
  invoiceNumber?: string;
  paymentMethod?: string;
  description?: string;
  subtotal: string;
  tax?: string;
  total: string;
  items: DocumentItem[];
}

export interface Document {
  id: number;
  userId?: number;
  templateId?: number;
  fileName?: string;
  originalFile: string;
  extractedData: ExtractedDocumentData;
  confidence?: number;
  tags?: string[];
  status: string;
  createdAt: Date;
}

export interface DashboardStats {
  processedCount: number;
  avgConfidence: number;
  timeSaved: number;
  templatesCount: number;
}

export interface DocumentProcessingState {
  step: 'upload' | 'ocr' | 'ai_processing' | 'review' | 'complete';
  file?: File;
  filePath?: string;
  extractedText?: string;
  extractedData?: ExtractedDocumentData;
  confidence?: number;
  documentId?: number;
  error?: string;
}
