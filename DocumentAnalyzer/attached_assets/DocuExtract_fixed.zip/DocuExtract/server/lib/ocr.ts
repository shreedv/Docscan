import Tesseract from 'tesseract.js';
import fs from 'fs';
import path from 'path';

/**
 * Extract text from an image file using Tesseract OCR
 * @param imagePath Path to the image file
 * @returns Promise with extracted text
 */
export async function extractTextFromImage(imagePath: string): Promise<string> {
  try {
    if (!fs.existsSync(imagePath)) {
      throw new Error(`File does not exist: ${imagePath}`);
    }

    // Get file extension
    const ext = path.extname(imagePath).toLowerCase();
    
    // Perform OCR based on file type
    if (['.jpg', '.jpeg', '.png'].includes(ext)) {
      console.log(`Processing image with Tesseract: ${imagePath}`);
      
      const result = await Tesseract.recognize(
        imagePath,
        'eng', // Language
        { 
          logger: m => console.log(m),
        }
      );
      
      return result.data.text;
    } else if (ext === '.pdf') {
      throw new Error('PDF files are not supported in this demo. Please upload a JPG or PNG.');
      // Note: For a real implementation, we would need a PDF processing library
      // like pdf.js or pdf-parse to extract text from PDFs
      throw new Error('PDF processing not implemented yet');
    } else {
      throw new Error(`Unsupported file type: ${ext}`);
    }
  } catch (error) {
    console.error('OCR Error:', error);
    throw new Error(`OCR processing failed: ${error.message}`);
  }
}
