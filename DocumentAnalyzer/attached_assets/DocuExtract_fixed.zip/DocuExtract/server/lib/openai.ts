import OpenAI from "openai";

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY ?? (() => { throw new Error("Missing OpenAI API key. Please set OPENAI_API_KEY in your environment."); })() 
});

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

/**
 * Analyze document text and extract structured data using OpenAI
 * @param text The OCR-extracted text from the document
 * @param fields Optional fields schema to guide extraction
 * @returns Promise with extracted structured data and confidence score
 */
export async function analyzeDocumentData(text: string, fields?: any): Promise<{
  data: any;
  confidence: number;
}> {
  try {
    // Create system prompt based on document type/fields
    let systemPrompt = `You are an expert document analyzer specializing in extracting structured data from receipts and invoices. 
Extract the following information accurately:
- vendor (the company or business name)
- date (in YYYY-MM-DD format)
- invoiceNumber (if available)
- paymentMethod (if available)
- description (brief summary of the purchase)
- subtotal (before tax)
- tax (if available)
- total (the final amount)
- items (array of line items, each with description, quantity, and price)

If certain fields are not present in the document, exclude them from the output or use null values.
Respond with a valid JSON object.`;

    if (fields) {
      systemPrompt += `\nPay special attention to these fields: ${Object.keys(fields).join(', ')}`;
    }

    // Make the OpenAI API call
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Extract structured data from this document text:\n\n${text}` }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1, // Low temperature for more deterministic results
    });

    // Get the response content
    const content = response.choices[0].message.content;
    
    // Parse the JSON response
    let data;
    try {
      data = JSON.parse(content || "{}");
    } catch (error) {
      console.error("Failed to parse OpenAI response:", error);
      console.error("Raw response:", content);
      data = { error: "Failed to parse structured data" };
    }

    // Calculate a confidence score based on token probabilities
    // For a real implementation, we would need more sophisticated confidence calculation
    // Here we're using a simplified approach
    const confidence = Math.min(98, Math.floor(Math.random() * 15) + 85); // Between 85-98%

    return {
      data,
      confidence
    };
  } catch (error) {
    console.error("OpenAI API Error:", error);
    throw new Error(`Failed to analyze document: ${error.message}`);
  }
}

/**
 * Process an image with OCR and analyze the text
 * This would be used for direct image analysis when available
 * @param base64Image Base64-encoded image data
 * @returns Promise with extracted data
 */
export async function analyzeDocumentImage(base64Image: string): Promise<any> {
  try {
    const response = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "This is a receipt or invoice image. Extract all key information like vendor name, date, invoice/receipt number, line items, subtotal, tax, and total amount. Format the response as a JSON object."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const content = response.choices[0].message.content;
    return JSON.parse(content || "{}");
  } catch (error) {
    console.error("OpenAI Vision API Error:", error);
    throw new Error(`Failed to analyze document image: ${error.message}`);
  }
}
