import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { extractTextFromImage } from "./lib/ocr";
import { analyzeDocumentData } from "./lib/openai";
import { insertDocumentSchema, insertTemplateSchema } from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod";

// Set up storage for uploaded files
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    }
  }),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max file size
  },
  fileFilter: function (req, file, cb) {
    const filetypes = /jpeg|jpg|png|pdf/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error("Only .png, .jpg, .jpeg, and .pdf files are allowed"));
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handling middleware
  app.use((err: Error, req: Request, res: Response, next: Function) => {
    console.error(err.stack);
    if (err instanceof ZodError) {
      return res.status(400).json({ message: "Validation error", errors: err.errors });
    }
    return res.status(500).json({ message: err.message || "Something went wrong" });
  });

  // API ROUTES
  
  // Templates routes
  app.get('/api/templates', async (req, res) => {
    try {
      const templates = await storage.getTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  app.get('/api/templates/:id', async (req, res) => {
    try {
      const template = await storage.getTemplate(Number(req.params.id));
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch template" });
    }
  });

  app.post('/api/templates', async (req, res) => {
    try {
      const template = insertTemplateSchema.parse(req.body);
      const newTemplate = await storage.createTemplate(template);
      res.status(201).json(newTemplate);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create template" });
    }
  });

  // Documents routes
  app.get('/api/documents', async (req, res) => {
    try {
      const documents = await storage.getDocuments();
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.get('/api/documents/recent', async (req, res) => {
    try {
      const limit = req.query.limit ? Number(req.query.limit) : 5;
      const documents = await storage.getRecentDocuments(limit);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent documents" });
    }
  });

  app.get('/api/documents/:id', async (req, res) => {
    try {
      const document = await storage.getDocument(Number(req.params.id));
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch document" });
    }
  });

  // Save document with frontend-processed data
  app.post('/api/documents/save', async (req, res) => {
    try {
      const { 
        extractedText,
        extractedData, 
        confidence, 
        fileName, 
        templateId 
      } = req.body;
      
      if (!extractedData) {
        return res.status(400).json({ message: "No extracted data provided" });
      }

      // Generate a unique filename to store the document
      const timestamp = Date.now();
      const originalFile = `uploads/${timestamp}-${fileName || 'document.txt'}`;
      
      // Save extracted text to a file (optional)
      if (extractedText) {
        await fs.promises.writeFile(originalFile, extractedText);
      }

      // Create document record
      const document = await storage.createDocument({
        userId: 1, // Default user for now
        templateId: templateId || null,
        fileName: fileName || 'Untitled Document',
        originalFile,
        extractedData,
        confidence: confidence || 0,
        tags: [],
        status: 'processed'
      });
      
      res.status(201).json({
        document,
        success: true
      });
    } catch (error) {
      console.error("Document save error:", error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: "Failed to save document", error: errorMessage });
    }
  });
  
  // Legacy endpoint for file uploads (kept for backward compatibility)
  app.post('/api/documents/process', upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Since OCR is now done in the frontend, we just save basic info
      // and redirect to the frontend processing
      res.status(200).json({
        message: "File uploaded successfully. Please use /api/documents/save endpoint with extracted data.",
        filePath: req.file.path,
        fileName: req.file.originalname
      });
    } catch (error) {
      console.error("Document upload error:", error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: "Failed to upload document", error: errorMessage });
    }
  });

  // Save processed document
  app.post('/api/documents', async (req, res) => {
    try {
      const document = insertDocumentSchema.parse(req.body);
      const newDocument = await storage.createDocument(document);
      res.status(201).json(newDocument);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save document" });
    }
  });

  // Update document
  app.put('/api/documents/:id', async (req, res) => {
    try {
      const id = Number(req.params.id);
      const document = await storage.getDocument(id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      const updatedDocument = await storage.updateDocument(id, req.body);
      res.json(updatedDocument);
    } catch (error) {
      res.status(500).json({ message: "Failed to update document" });
    }
  });

  // Dashboard stats
  app.get('/api/stats', async (req, res) => {
    try {
      const documents = await storage.getDocuments();
      const templates = await storage.getTemplates();
      
      // Calculate stats
      const processedCount = documents.length;
      const avgConfidence = documents.reduce((sum, doc) => sum + (doc.confidence || 0), 0) / (processedCount || 1);
      const timeSaved = processedCount * 5; // Estimate 5 minutes saved per document
      const templatesCount = templates.length;
      
      res.json({
        processedCount,
        avgConfidence: Math.round(avgConfidence * 10) / 10,
        timeSaved,
        templatesCount
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
