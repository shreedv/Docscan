-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL
);

-- Create templates table
CREATE TABLE IF NOT EXISTS templates (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  fields JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  template_id INTEGER REFERENCES templates(id),
  file_name TEXT,
  original_file TEXT NOT NULL,
  extracted_data JSONB NOT NULL,
  confidence INTEGER,
  tags TEXT[],
  status TEXT NOT NULL DEFAULT 'processed',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Insert default templates
INSERT INTO templates (name, description, fields) VALUES
  ('Receipt Processor', 'Extracts date, vendor, total, tax', '{"vendor":"string","date":"date","invoiceNumber":"string","total":"number","tax":"number","paymentMethod":"string","items":"array"}'),
  ('Invoice Parser', 'Invoice #, date, due date, line items', '{"vendor":"string","date":"date","invoiceNumber":"string","dueDate":"date","total":"number","subtotal":"number","tax":"number","items":"array"}'),
  ('Expense Report', 'Categories expenses by type', '{"vendor":"string","date":"date","total":"number","category":"string","paymentMethod":"string","description":"string"}')
ON CONFLICT (id) DO NOTHING;