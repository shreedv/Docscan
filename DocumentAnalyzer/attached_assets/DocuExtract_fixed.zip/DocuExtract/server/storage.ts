import { 
  users, type User, type InsertUser,
  templates, type Template, type InsertTemplate,
  documents, type Document, type InsertDocument
} from "@shared/schema";

// Storage interface for all CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Template operations
  getTemplate(id: number): Promise<Template | undefined>;
  getTemplates(): Promise<Template[]>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template | undefined>;
  deleteTemplate(id: number): Promise<boolean>;
  
  // Document operations
  getDocument(id: number): Promise<Document | undefined>;
  getDocuments(userId?: number): Promise<Document[]>;
  getRecentDocuments(limit?: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private templates: Map<number, Template>;
  private documents: Map<number, Document>;
  private userId: number;
  private templateId: number;
  private documentId: number;

  constructor() {
    this.users = new Map();
    this.templates = new Map();
    this.documents = new Map();
    this.userId = 1;
    this.templateId = 1;
    this.documentId = 1;
    
    // Initialize with sample templates
    this.createTemplate({
      name: "Receipt Processor",
      description: "Extracts date, vendor, total, tax",
      fields: {
        vendor: "string",
        date: "date",
        invoiceNumber: "string",
        total: "number",
        tax: "number",
        paymentMethod: "string",
        items: "array"
      }
    });
    
    this.createTemplate({
      name: "Invoice Parser",
      description: "Invoice #, date, due date, line items",
      fields: {
        vendor: "string",
        date: "date",
        invoiceNumber: "string",
        dueDate: "date",
        total: "number",
        subtotal: "number",
        tax: "number",
        items: "array"
      }
    });
    
    this.createTemplate({
      name: "Expense Report",
      description: "Categories expenses by type",
      fields: {
        vendor: "string",
        date: "date",
        total: "number",
        category: "string",
        paymentMethod: "string",
        description: "string"
      }
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Template methods
  async getTemplate(id: number): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async getTemplates(): Promise<Template[]> {
    return Array.from(this.templates.values());
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const id = this.templateId++;
    const newTemplate: Template = {
      ...template,
      id,
      createdAt: new Date()
    };
    this.templates.set(id, newTemplate);
    return newTemplate;
  }

  async updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template | undefined> {
    const existingTemplate = this.templates.get(id);
    if (!existingTemplate) return undefined;
    
    const updatedTemplate = {
      ...existingTemplate,
      ...template
    };
    
    this.templates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteTemplate(id: number): Promise<boolean> {
    return this.templates.delete(id);
  }

  // Document methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocuments(userId?: number): Promise<Document[]> {
    const allDocuments = Array.from(this.documents.values());
    if (userId) {
      return allDocuments.filter(doc => doc.userId === userId);
    }
    return allDocuments;
  }

  async getRecentDocuments(limit: number = 5): Promise<Document[]> {
    const allDocuments = Array.from(this.documents.values());
    return allDocuments
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const id = this.documentId++;
    const newDocument: Document = {
      ...document,
      id,
      createdAt: new Date()
    };
    this.documents.set(id, newDocument);
    return newDocument;
  }

  async updateDocument(id: number, documentUpdate: Partial<InsertDocument>): Promise<Document | undefined> {
    const existingDocument = this.documents.get(id);
    if (!existingDocument) return undefined;
    
    const updatedDocument = {
      ...existingDocument,
      ...documentUpdate
    };
    
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }
}

import { DatabaseStorage } from './storage/DatabaseStorage';

// Create and export database storage as the active storage implementation
export const storage = new DatabaseStorage();
