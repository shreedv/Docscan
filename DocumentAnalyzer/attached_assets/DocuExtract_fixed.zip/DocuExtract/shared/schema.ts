import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Document templates schema
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  fields: jsonb("fields").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTemplateSchema = createInsertSchema(templates).pick({
  name: true,
  description: true,
  fields: true,
});

// Processed documents schema
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  templateId: integer("template_id").references(() => templates.id),
  fileName: text("file_name"),
  originalFile: text("original_file").notNull(), // path or reference to stored file
  extractedData: jsonb("extracted_data").notNull(),
  confidence: integer("confidence"),
  tags: text("tags").array(),
  status: text("status").notNull().default("processed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  userId: true,
  templateId: true,
  fileName: true,
  originalFile: true,
  extractedData: true,
  confidence: true,
  tags: true,
  status: true,
});

// Define TS types from schema
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Template = typeof templates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

// Document items schema for line items in receipts/invoices
export type DocumentItem = {
  description: string;
  quantity: number;
  price: string;
};

// Extended document data type (for frontend use)
export type ExtractedDocumentData = {
  vendor: string;
  date: string;
  invoiceNumber?: string;
  paymentMethod?: string;
  description?: string;
  subtotal: string;
  tax?: string;
  total: string;
  items: DocumentItem[];
};
